<!-- footer -->
<footer class="main-footer">
    <div class="pull-right hidden-xs">
        <b>Version</b> 1.1.1
    </div>
    2020 &copy; Created by<strong> <a href="#">MyMango.id</a>.</strong>
</footer>
<!-- ./footer -->